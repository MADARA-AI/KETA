#include <linux/kernel.h>

bool init_key(char* key, size_t len_key);
bool verify_key_offline(char* key, size_t len_key);
