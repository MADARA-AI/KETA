#include <linux/kernel.h>

uintptr_t get_module_base(pid_t pid, char* name);
