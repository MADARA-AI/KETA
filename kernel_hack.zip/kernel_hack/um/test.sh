make clean && make
#sudo ./main
#sudo dmesg
adb push main /data/local/tmp
#adb shell ./data/local/tmp/main
